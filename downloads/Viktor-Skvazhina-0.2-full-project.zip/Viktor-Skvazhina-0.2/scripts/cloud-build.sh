#!/usr/bin/env bash
# Builds in a dedicated mirror so the historical build outputs tracked in Git stay untouched.
set -euo pipefail
export ANDROID_HOME=/workspace/android-sdk
export ANDROID_USER_HOME=/workspace/android-user
export GRADLE_USER_HOME=/workspace/gradle-home
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$ANDROID_HOME/platforms/android-35/android.jar"
python3 - "$project_root" <<'PY'
from pathlib import Path
import shutil, sys
source = Path(sys.argv[1]) / 'SechinQuiz_3'
destination = Path('/workspace/show-build')
shutil.copytree(source, destination, dirs_exist_ok=True,
    ignore=shutil.ignore_patterns('build', '.gradle', '.idea', '*.zip', '.DS_Store', 'local.properties'))
(destination / 'local.properties').write_text('sdk.dir=/workspace/android-sdk\n')
PY
cd /workspace/show-build
if [ "$#" -eq 0 ]; then set -- :app:assembleDebug; fi
sh ./gradlew --no-daemon "$@"
