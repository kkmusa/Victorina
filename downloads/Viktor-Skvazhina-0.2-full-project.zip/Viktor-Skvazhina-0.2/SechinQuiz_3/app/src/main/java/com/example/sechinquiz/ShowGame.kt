package com.example.sechinquiz

import java.io.Serializable
import kotlin.random.Random

enum class GameMode { MILLION, DUEL }
enum class Phase { HANDOFF, QUESTION, REVEAL, FEEDBACK, RESULT }
data class Lifelines(val fifty: Boolean = false, val audience: Boolean = false) : Serializable

data class ShowGame(
    val mode: GameMode,
    val names: List<String>,
    val deck: List<QuizQuestion>,
    val turn: Int = 0,
    val scores: List<Int> = listOf(0, 0),
    val aids: List<Lifelines> = listOf(Lifelines(), Lifelines()),
    val phase: Phase = if (mode == GameMode.DUEL) Phase.HANDOFF else Phase.QUESTION,
    val order: List<Int> = listOf(0, 1, 2, 3).shuffled(),
    val hidden: Set<Int> = emptySet(),
    val votes: List<Int>? = null,
    val selected: Int? = null,
    val prize: Int = 0,
    val walked: Boolean = false,
    val callAt: Int = -1,
    val callSeen: Boolean = false,
    val site: Int = Random.nextInt(10, 999),
    val callVariant: Int = Random.nextInt(3),
    val usedIds: Set<Int> = deck.map { it.id }.toSet(),
    val sessionId: String = java.util.UUID.randomUUID().toString(),
    val recorded: Boolean = false
) : Serializable {
    val player get() = if (mode == GameMode.DUEL) turn % 2 else 0
    val question get() = deck[turn]
    val round get() = if (mode == GameMode.DUEL) turn / 2 + 1 else turn + 1
    val correct get() = selected == question.correctOriginalIndex
    val won get() = mode == GameMode.MILLION && scores[0] == 15 && !walked
    val winner get() = if (scores[0] == scores[1]) null else if (scores[0] > scores[1]) names[0] else names[1]

    fun choose(answer: Int): ShowGame =
        if (phase != Phase.QUESTION || answer in hidden || answer !in order) this
        else copy(selected = answer, phase = Phase.REVEAL)

    fun reveal(): ShowGame {
        if (phase != Phase.REVEAL) return this
        val nextScores = scores.toMutableList()
        if (correct) nextScores[player]++
        return copy(scores = nextScores, phase = Phase.FEEDBACK)
    }

    fun next(bank: List<QuizQuestion>, random: Random = Random.Default): ShowGame {
        if (phase != Phase.FEEDBACK) return this
        if (mode == GameMode.MILLION) {
            if (!correct || turn == 14) return copy(phase = Phase.RESULT, prize = if (correct) 1_000_000 else guaranteed(scores[0]))
        } else if (turn == deck.lastIndex) {
            // A deciding result is evaluated only after BOTH players answered.
            if (scores[0] != scores[1]) return copy(phase = Phase.RESULT)
            val available = bank.filter { it.id !in usedIds && it.difficulty == 3 }
            if (available.size < 2) return copy(phase = Phase.RESULT) // honest draw if the bank is exhausted
            val pair = available.shuffled(random).take(2)
            return freshTurn(copy(deck = deck + pair, usedIds = usedIds + pair.map { it.id }), random)
        }
        return freshTurn(this, random)
    }

    private fun freshTurn(game: ShowGame, random: Random): ShowGame = game.copy(
        turn = turn + 1, phase = if (mode == GameMode.DUEL) Phase.HANDOFF else Phase.QUESTION,
        order = listOf(0, 1, 2, 3).shuffled(random), hidden = emptySet(), votes = null, selected = null
    )

    fun takePrize() = if (mode == GameMode.MILLION && phase == Phase.QUESTION)
        copy(phase = Phase.RESULT, walked = true, prize = ladder.getOrElse(scores[0] - 1) { 0 }) else this

    fun fifty(random: Random = Random.Default): ShowGame {
        if (phase != Phase.QUESTION || aids[player].fifty) return this
        val removed = order.filter { it != question.correctOriginalIndex }.shuffled(random).take(2).toSet()
        return copy(hidden = removed, votes = null, aids = aids.mapIndexed { i, a -> if (i == player) a.copy(fifty = true) else a })
    }

    fun audience(random: Random = Random.Default): ShowGame {
        if (phase != Phase.QUESTION || aids[player].audience) return this
        val visible = order.filter { it !in hidden }
        val preferred = if (random.nextInt(100) < 85 - question.difficulty * 15) question.correctOriginalIndex else visible.random(random)
        val weights = order.map { if (it in hidden) 0 else if (it == preferred) random.nextInt(50, 85) else random.nextInt(5, 30) }
        val total = weights.sum()
        val percentages = weights.map { it * 100 / total }.toMutableList()
        percentages[order.indexOf(preferred)] += 100 - percentages.sum()
        return copy(votes = percentages, aids = aids.mapIndexed { i, a -> if (i == player) a.copy(audience = true) else a })
    }

    companion object {
        val ladder = listOf(100, 200, 300, 500, 1_000, 2_000, 4_000, 8_000, 16_000, 32_000, 64_000, 125_000, 250_000, 500_000, 1_000_000)
        fun guaranteed(correct: Int) = when { correct >= 10 -> 32_000; correct >= 5 -> 1_000; else -> 0 }
        fun start(mode: GameMode, bank: List<QuizQuestion>, names: List<String> = listOf("Игрок 1", "Игрок 2"), random: Random = Random.Default): ShowGame {
            val groups = (0..3).associateWith { tier -> bank.filter { it.difficulty == tier }.shuffled(random).toMutableList() }
            val tiers = if (mode == GameMode.MILLION) List(5) { 0 } + List(4) { 1 } + List(3) { 2 } + List(3) { 3 }
                else listOf(0, 0, 1, 2, 3).flatMap { listOf(it, it) }
            val deck = tiers.map { tier -> requireNotNull(groups[tier]).removeAt(0) }
            return ShowGame(mode, names.mapIndexed { i, s -> s.trim().take(24).ifBlank { "Игрок ${i + 1}" } }, deck,
                order = listOf(0, 1, 2, 3).shuffled(random),
                callAt = if (mode == GameMode.MILLION && random.nextInt(100) < 40) random.nextInt(2, 12) else -1,
                site = random.nextInt(10, 999), callVariant = random.nextInt(3))
        }
    }
}
