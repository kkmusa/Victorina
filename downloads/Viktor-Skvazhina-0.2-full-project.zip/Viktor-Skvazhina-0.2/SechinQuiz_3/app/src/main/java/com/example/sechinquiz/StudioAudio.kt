package com.example.sechinquiz

import android.content.Context
import android.media.MediaPlayer

/** Independent music, speech and effect channels; all stop when the Activity pauses. */
object StudioAudio {
    private var music: MediaPlayer? = null
    private var speech: MediaPlayer? = null
    private var effect: MediaPlayer? = null
    private var generation = 0
    private var volume = 0.25f
    fun background(context: Context, enabled: Boolean, level: Float) {
        volume = level
        if (!enabled) { music?.release(); music = null; return }
        if (music == null) music = MediaPlayer.create(context, R.raw.studio_loop)?.apply { isLooping = true; start() }
        duck(speech != null)
    }
    private fun duck(speaking: Boolean) { val v = volume * if (speaking) 0.18f else 1f; music?.setVolume(v, v) }
    fun stopSpeech() {
        generation++
        speech?.setOnCompletionListener(null); speech?.release(); speech = null; duck(false)
    }
    fun speak(context: Context, resources: List<Int>, onDone: () -> Unit = {}) {
        stopSpeech()
        val token = generation
        fun play(index: Int) {
            if (token != generation) return
            if (index == resources.size) { duck(false); onDone(); return }
            val p = MediaPlayer.create(context, resources[index])
            if (p == null) { play(index + 1); return }
            speech = p; duck(true)
            fun advance() { p.release(); if (speech === p) speech = null; play(index + 1) }
            p.setOnCompletionListener { advance() }
            p.setOnErrorListener { _, _, _ -> advance(); true }
            p.start()
        }
        play(0)
    }
    fun cue(context: Context, id: Int, enabled: Boolean) {
        effect?.release(); effect = null
        if (!enabled) return
        effect = MediaPlayer.create(context, id)?.apply {
            setVolume(0.65f, 0.65f)
            setOnCompletionListener { it.release(); if (effect === it) effect = null }
            start()
        }
    }
    fun stop() { stopSpeech(); music?.release(); music = null; effect?.release(); effect = null }
}
