package com.example.sechinquiz

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ViktorHost(line: String, goldSuit: Boolean, away: Boolean, happy: Boolean, animated: Boolean) {
    val motion = rememberInfiniteTransition(label = "viktor")
    val idle by motion.animateFloat(-2f, 2f, infiniteRepeatable(tween(1700), RepeatMode.Reverse), label = "breathing")
    val blink by motion.animateFloat(1f, 0.08f, infiniteRepeatable(keyframes { durationMillis = 4600; 1f at 0; 1f at 4300; 0.08f at 4420; 1f at 4540 }), label = "blink")
    val exit by animateFloatAsState(if (away && animated) 280f else 0f, tween(if (away) 250 else 400), label = "run")
    Row(Modifier.fillMaxWidth().background(Color(0xCC101D36), RoundedCornerShape(22.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(92.dp, 138.dp).offset(x = exit.dp, y = if (animated) idle.dp else 0.dp)) {
            val sx = size.width / 100; val sy = size.height / 150
            fun o(x: Float, y: Float) = Offset(x * sx, y * sy)
            val skin = Color(0xFFF1BD91)
            val suit = if (goldSuit) Color(0xFFC99B36) else Color(0xFF2D5586)
            drawOval(Color(0x44000000), o(12f, 140f), Size(80*sx, 8*sy))
            drawLine(Color(0xFF111D31), o(39f,115f),o(34f,141f),12*sx)
            drawLine(Color(0xFF111D31), o(64f,115f),o(70f,141f),12*sx)
            drawRoundRect(suit,o(22f,66f),Size(60*sx,61*sy),androidx.compose.ui.geometry.CornerRadius(14*sx))
            drawPath(Path().apply { moveTo(37*sx,67*sy);lineTo(65*sx,67*sy);lineTo(52*sx,106*sy);close() },Color.White)
            drawLine(Color(0xFFE8B74A),o(51f,77f),o(53f,98f),5*sx)
            drawLine(suit,o(24f,78f),o(12f,109f),11*sx)
            drawLine(suit,o(78f,78f),o(91f,if(happy)56f else 104f),11*sx)
            drawCircle(skin,6*sx,o(12f,110f));drawCircle(skin,6*sx,o(91f,if(happy)54f else 106f))
            drawRoundRect(skin,o(27f,13f),Size(49*sx,54*sy),androidx.compose.ui.geometry.CornerRadius(19*sx))
            drawArc(Color(0xFF302623),180f,180f,true,o(24f,5f),Size(54*sx,39*sy))
            drawLine(Color(0xFF302623),o(35f,31f),o(44f,29f),2*sx)
            drawLine(Color(0xFF302623),o(58f,29f),o(67f,31f),2*sx)
            val eye = if(animated) blink else 1f
            drawOval(Color(0xFF20293A),o(38f,35f),Size(4*sx,6*sy*eye))
            drawOval(Color(0xFF20293A),o(60f,35f),Size(4*sx,6*sy*eye))
            drawArc(Color(0xFF803F35),0f,180f,false,o(41f,45f),Size(23*sx,(if(happy)15 else 8)*sy),style=Stroke(2*sx))
            drawCircle(Color(0xFFE8B74A),3*sx,o(72f,88f))
        }
        Column(Modifier.weight(1f).padding(start=10.dp)) {
            Text("ВИКТОР СКВАЖИНА",color=Color(0xFFE8B74A),fontSize=11.sp)
            Spacer(Modifier.height(8.dp))
            Text(line,color=Color.White,fontSize=15.sp,lineHeight=21.sp)
        }
    }
}
