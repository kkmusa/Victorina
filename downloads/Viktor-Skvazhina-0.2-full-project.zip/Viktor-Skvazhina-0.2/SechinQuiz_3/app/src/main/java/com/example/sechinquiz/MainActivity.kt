package com.example.sechinquiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { StudioApp() } }
    override fun onResume() { super.onResume(); foreground = true }
    override fun onPause() { foreground = false; StudioAudio.stop(); super.onPause() }
    override fun onDestroy() { StudioAudio.stop(); super.onDestroy() }
    companion object { var foreground by mutableStateOf(false) }
}

private val Gold = Color(0xFFECC168)
private val Muted = Color(0xFF9DAEC9)
private fun points(n: Int) = "%,d".format(java.util.Locale.US, n).replace(',', ' ')
private val GameSaver = Saver<ShowGame?, ByteArray>(
    save = { game -> ByteArrayOutputStream().use { bytes -> ObjectOutputStream(bytes).use { it.writeObject(game) }; bytes.toByteArray() } },
    restore = { bytes -> ObjectInputStream(ByteArrayInputStream(bytes)).use { it.readObject() as? ShowGame } }
)

@Composable
fun StudioApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("studio", 0) }
    var page by rememberSaveable { mutableStateOf("menu") }
    var game by rememberSaveable(stateSaver = GameSaver) { mutableStateOf<ShowGame?>(null) }
    var first by rememberSaveable { mutableStateOf("Игрок 1") }
    var second by rememberSaveable { mutableStateOf("Игрок 2") }
    var voice by remember { mutableStateOf(prefs.getBoolean("voice", true)) }
    var answersVoice by remember { mutableStateOf(prefs.getBoolean("answers", true)) }
    var music by remember { mutableStateOf(prefs.getBoolean("music", true)) }
    var effects by remember { mutableStateOf(prefs.getBoolean("effects", true)) }
    var animated by remember { mutableStateOf(prefs.getBoolean("animated", true)) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("volume", .25f)) }
    var wins by remember { mutableIntStateOf(prefs.getInt("wins", 0)) }
    var noAids by remember { mutableStateOf(prefs.getBoolean("noAids", false)) }
    var best by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    var goldSuit by remember { mutableStateOf(prefs.getBoolean("goldSuit", false)) }
    var studio by remember { mutableIntStateOf(prefs.getInt("studio", 0)) }
    var confirmExit by remember { mutableStateOf(false) }
    val active = MainActivity.foreground

    LaunchedEffect(voice, answersVoice, music, effects, animated, volume, goldSuit, studio) {
        prefs.edit().putBoolean("voice",voice).putBoolean("answers",answersVoice).putBoolean("music",music)
            .putBoolean("effects",effects).putBoolean("animated",animated).putFloat("volume",volume)
            .putBoolean("goldSuit",goldSuit).putInt("studio",studio).apply()
    }
    LaunchedEffect(active, music, volume) { if (active) StudioAudio.background(context,music,volume) else StudioAudio.stop() }
    DisposableEffect(Unit) { onDispose { StudioAudio.stop() } }
    BackHandler(page != "menu") { if(page == "play" && game?.phase != Phase.RESULT) confirmExit = true else { StudioAudio.stopSpeech(); page = "menu" } }

    fun start(mode: GameMode) {
        StudioAudio.stopSpeech()
        game = ShowGame.start(mode, QuestionBank.playable, listOf(first,second))
        page = "play"
    }
    fun update(next: ShowGame) { game = next }

    LaunchedEffect(game?.phase, game?.recorded) {
        val g = game ?: return@LaunchedEffect
        if (g.phase == Phase.RESULT && !g.recorded) {
            if (g.mode == GameMode.MILLION && prefs.getString("lastResult",null) != g.sessionId) {
                best = maxOf(best,g.prize)
                if(g.won) { wins++; if(!g.aids[0].fifty && !g.aids[0].audience) noAids = true }
                prefs.edit().putInt("wins",wins).putInt("best",best).putBoolean("noAids",noAids).putString("lastResult",g.sessionId).apply()
            }
            game = g.copy(recorded = true)
        }
    }
    val gradient = when(studio) {
        1 -> listOf(Color(0xFF101032), Color(0xFF132C49), Color(0xFF090D20))
        2 -> listOf(Color(0xFF31210B), Color(0xFF142B4B), Color(0xFF160E08))
        else -> listOf(Color(0xFF071021), Color(0xFF142B4B), Color(0xFF080F20))
    }
    MaterialTheme(colorScheme = darkColorScheme(primary=Gold,onPrimary=Color(0xFF172139),surface=Color(0xFF15243D),background=Color(0xFF071021))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(gradient)).safeDrawingPadding()) {
            when(page) {
                "menu" -> Page {
                    Text("ПРОМЫСЕЛ • ИНТЕЛЛЕКТ • ХАРАКТЕР",color=Gold,fontSize=11.sp,letterSpacing=2.sp)
                    Text("ПУТЬ К\nМИЛЛИОНУ",color=Color.White,fontWeight=FontWeight.Black,fontSize=42.sp,lineHeight=46.sp)
                    Text("Викторина для операторов ДНГ",color=Muted)
                    ViktorHost("Пятнадцать вопросов. Один миллион. И ни одного звонка начальству. Почти.",goldSuit,false,true,animated)
                    Action("Путь к миллиону", "15 вопросов · 2 подсказки") { start(GameMode.MILLION) }
                    Action("Дуэль", "Два игрока · одно устройство") { page = "duel" }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                        TextButton(onClick={page="rewards"}) { Text("Награды") }
                        TextButton(onClick={page="settings"}) { Text("Настройки") }
                    }
                    Text("Рекорд: ${points(best)} баллов · Побед: $wins",color=Gold)
                    Text("5-й и 10-й вопросы — несгораемые уровни. Можно забрать баллы и завершить игру. Баллы игровые.",color=Muted,fontSize=13.sp)
                }
                "duel" -> Page {
                    Title("Дуэль")
                    Text("По 5 вопросов каждому. Ошибка не завершает игру. При ничьей — парные дополнительные раунды.",color=Muted)
                    OutlinedTextField(first,{first=it.take(24)},label={Text("Первый игрок")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(second,{second=it.take(24)},label={Text("Второй игрок")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Text("У каждого свои подсказки. Передавайте телефон только на экране смены игрока.",color=Muted)
                    Action("Начать дуэль") { start(GameMode.DUEL) }
                    TextButton(onClick={page="menu"}) { Text("В меню") }
                }
                "settings" -> Page {
                    Title("Звук и анимация")
                    Toggle("Озвучка вопросов",voice) { voice=it }
                    Toggle("Читать варианты ответов",answersVoice) { answersVoice=it }
                    Toggle("Музыка студии",music) { music=it }
                    Text("Громкость музыки",color=Muted)
                    Slider(volume,{volume=it},valueRange=0f..1f)
                    Toggle("Звуковые эффекты",effects) { effects=it }
                    Toggle("Анимация ведущего",animated) { animated=it }
                    Text("Существующая озвучка сохранена для лёгких вопросов. Новые реплики Виктора и остальные вопросы пока отображаются текстом.",color=Muted,fontSize=13.sp)
                    TextButton(onClick={page="menu"}) { Text("В меню") }
                }
                "rewards" -> Page {
                    Title("Гардероб и студия")
                    Text("Побед: $wins · Рекорд: ${points(best)}",color=Gold)
                    Reward("Легенда промысла", "Первая победа: золотой костюм Виктора", wins >= 1)
                    if(wins>=1) Toggle("Золотой костюм",goldSuit) { goldSuit=it }
                    Reward("Ночная смена", "Три победы: неоновая студия",wins>=3)
                    Reward("Высшая лига", "Победа без подсказок: праздничная студия",noAids)
                    Action("Классическая студия") { studio=0 }
                    if(wins>=3) Action("Ночная смена") { studio=1 }
                    if(noAids) Action("Высшая лига") { studio=2 }
                    ViktorHost("Костюм золотой. Ответы по-прежнему ваши.",goldSuit,false,true,animated)
                    TextButton(onClick={page="menu"}) { Text("В меню") }
                }
                "play" -> game?.let { g ->
                    when(g.phase) {
                        Phase.RESULT -> Page {
                            Title(if(g.mode==GameMode.DUEL) "Дуэль завершена" else if(g.won) "ПРОМЫСЕЛ ПОД КОНТРОЛЕМ!" else "Игра завершена")
                            Text(if(g.mode==GameMode.DUEL) "${g.names[0]} — ${g.scores[0]}\n${g.names[1]} — ${g.scores[1]}" else "${points(g.prize)}",color=Gold,fontSize=42.sp,fontWeight=FontWeight.Black)
                            Text(if(g.mode==GameMode.DUEL) g.winner?.let{"Победитель: $it"} ?: "Ничья — банк дополнительных вопросов исчерпан" else if(g.won) "Легенда промысла · 15 из 15" else if(g.walked) "Вы забрали игровые баллы" else "Правильных ответов: ${g.scores[0]}. Сохранён несгораемый результат.",color=Muted)
                            ViktorHost(if(g.won) "Пятнадцать из пятнадцати. На планёрке лучше молчи — ещё начальником назначат." else if(g.mode==GameMode.DUEL) "Телефон общий, а слава достанется не всем." else if(g.walked) "Забрали результат? Грамотно. Премию тоже заранее просите." else "Вот поэтому сначала инструктаж, потом кнопки.",goldSuit,false,g.won,animated)
                            if(g.won) Text("Открыт золотой костюм! Выбрать его можно в разделе «Награды».",color=Gold)
                            Action("Сыграть ещё") { start(g.mode) }
                            TextButton(onClick={page="rewards"}) { Text("Награды") }
                            TextButton(onClick={page="menu"}) { Text("В меню") }
                            LaunchedEffect(active) { if(active) StudioAudio.cue(context,if(g.won) R.raw.cue_win else R.raw.cue_correct,effects) }
                        }
                        Phase.HANDOFF -> Page {
                            Title("Передайте телефон")
                            Text(g.names[g.player],fontSize=34.sp,color=Gold,fontWeight=FontWeight.Bold)
                            Text("${if(g.round<=5) "Раунд ${g.round} из 5" else "Дополнительный раунд ${g.round-5}"}\nСчёт: ${g.scores[0]} : ${g.scores[1]}",color=Muted)
                            ViktorHost("Телефон передавайте аккуратно. Ответственность — вместе с ним.",goldSuit,false,false,animated)
                            Action("Я готов — показать вопрос") { update(g.copy(phase=Phase.QUESTION)) }
                            TextButton(onClick={confirmExit=true}) { Text("Завершить дуэль") }
                        }
                        else -> PlayQuestion(g,voice,answersVoice,effects,goldSuit,animated,active,::update,{confirmExit=true})
                    }
                }
            }
            if(confirmExit) AlertDialog(onDismissRequest={confirmExit=false}, title={Text("Выйти из игры?")},text={Text("Текущая партия завершится без сохранения результата.")}, confirmButton={TextButton(onClick={StudioAudio.stopSpeech();game=null;page="menu";confirmExit=false}){Text("Выйти")}},dismissButton={TextButton(onClick={confirmExit=false}){Text("Продолжить")}})
        }
    }
}

@Composable
private fun PlayQuestion(g: ShowGame, voice: Boolean, answersVoice: Boolean, effects: Boolean, goldSuit: Boolean, animated: Boolean, active: Boolean, update: (ShowGame)->Unit, exit: ()->Unit) {
    val context=LocalContext.current
    val current by rememberUpdatedState(g)
    var speechDone by remember(g.turn) { mutableStateOf(false) }
    var scene by rememberSaveable(g.turn) { mutableIntStateOf(0) }
    var ladder by remember { mutableStateOf(false) }
    var cashout by remember { mutableStateOf(false) }
    val sceneBusy = !g.callSeen && g.turn==g.callAt
    val ready = g.phase==Phase.QUESTION && !sceneBusy && active
    val question=g.question
    val letters=listOf("А","Б","В","Г")
    LaunchedEffect(g.turn,active,voice,answersVoice) {
        if(!active) return@LaunchedEffect
        speechDone=false
        if(current.phase!=Phase.QUESTION || !voice) { speechDone=true;return@LaunchedEffect }
        fun raw(name:String)=context.resources.getIdentifier(name,"raw",context.packageName)
        val ids=mutableListOf<Int>()
        val numbers=listOf(raw("question_number_${g.round}"),raw("question_number_${g.round}_alt")).filter{it!=0}
        // Never announce a number without a recorded question (only easy questions have audio).
        val q=if(question.difficulty==0) raw("l%04d_question".format(question.id)) else 0
        if(q!=0) {
            numbers.randomOrNull()?.let{ids+=it}; ids+=q
            if(answersVoice) g.order.forEachIndexed { pos,original ->
                ids+=raw(listOf("option_a","option_b","option_v","option_g")[pos])
                ids+=raw("l%04d_answer%d".format(question.id,original+1))
            }
        }
        StudioAudio.speak(context,ids.filter{it!=0}) { speechDone=true }
    }
    DisposableEffect(g.turn) { onDispose { StudioAudio.stopSpeech() } }
    LaunchedEffect(g.phase,active) {
        if(!active) return@LaunchedEffect
        if(g.phase==Phase.REVEAL) {
            StudioAudio.stopSpeech()
            delay(if(g.mode==GameMode.MILLION && g.round>=12) 2600 else 850)
            update(current.reveal())
        } else if(g.phase==Phase.FEEDBACK) {
            StudioAudio.cue(context,if(g.correct) R.raw.cue_correct else R.raw.cue_wrong,effects)
        }
    }
    LaunchedEffect(g.turn,speechDone,active) {
        if(!active || !speechDone || !sceneBusy || current.phase!=Phase.QUESTION) return@LaunchedEffect
        scene=1;StudioAudio.cue(context,R.raw.cue_phone,effects);delay(1800)
        scene=2;delay(3200)
        scene=3;delay(1000)
        scene=4;delay(2400)
        update(current.copy(callSeen=true));scene=0
    }
    val line=when {
        sceneBusy && scene==1 -> "Простите, нам в студию звонок…"
        sceneBusy && scene==2 -> "Оператор пульта: «Виктор, режимная скважина на кустовой площадке №${g.site} стоит. Когда запустите?»"
        sceneBusy && scene==3 -> "Стоит?.. Да… Дамы и господа, минутку!"
        sceneBusy && scene==4 -> listOf("Всё. Работаем. На чём вы собирались ошибиться?","Запустили. Надеюсь. Вернёмся к вашему давлению.","Я ничего не трогал. Оно само. Продолжаем!")[g.callVariant]
        g.phase==Phase.REVEAL && g.round>=12 && g.mode==GameMode.MILLION -> "Вы уверены?.. Хотя кнопку вы уже нажали."
        g.phase==Phase.REVEAL -> "Ответ принят. Сейчас проверим вашу квалификацию…"
        g.phase==Phase.FEEDBACK && g.correct -> listOf("Принято. На этот раз без замечаний.","Правильно! Даже диспетчер одобряет.","Работаем! Только не зазнавайтесь.")[g.turn%3]
        g.phase==Phase.FEEDBACK -> "Вот поэтому сначала инструктаж, потом кнопки."
        g.hidden.isNotEmpty() -> "Два варианта убрали. Ответственности меньше не стало."
        g.votes!=null -> "Зал проголосовал. Но наряд-допуск они за вас не подпишут."
        g.round>=12 -> "Тут уже серьёзно. Я даже шутку пока придержу."
        else -> listOf("Думаем спокойно. Аварийной кнопки здесь нет.","Четыре варианта. Начальство бы предложило пятый.","Не торопитесь. Но диспетчер уже поглядывает на часы.")[g.turn%3]
    }
    Page {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            Text(if(g.mode==GameMode.MILLION) "ВОПРОС ${g.round} / 15" else "${g.names[g.player]} · РАУНД ${g.round}",color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            TextButton(onClick=exit){Text("Выйти")}
        }
        if(g.mode==GameMode.MILLION) Text("На кону ${points(ShowGame.ladder[g.turn])} · Несгораемые ${points(ShowGame.guaranteed(g.scores[0]))}",color=Muted,fontSize=13.sp)
        else Text("${g.names[0]} ${g.scores[0]} : ${g.scores[1]} ${g.names[1]}",color=Muted)
        ViktorHost(line,goldSuit,scene==3,g.phase==Phase.FEEDBACK && g.correct,animated)
        Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF192D4B),modifier=Modifier.fillMaxWidth()) {
            Text(question.text,Modifier.padding(20.dp),fontSize=20.sp,lineHeight=28.sp,color=Color.White,fontWeight=FontWeight.SemiBold)
        }
        g.order.forEachIndexed { pos,original ->
            val hidden=original in g.hidden
            val revealed=g.phase==Phase.FEEDBACK
            val color=when {
                revealed && original==question.correctOriginalIndex -> Color(0xFF4DDE9A)
                revealed && original==g.selected -> Color(0xFFFF727D)
                original==g.selected -> Gold
                else -> Color(0xFF3C5271)
            }
            Row(Modifier.fillMaxWidth().border(1.dp,color,RoundedCornerShape(16.dp)).background(Color(0xCC101E35),RoundedCornerShape(16.dp))
                .clickable(enabled=ready && !hidden){StudioAudio.stopSpeech();update(current.choose(original))}.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                Text(letters[pos],color=if(hidden) Muted else Gold,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp))
                Text(if(hidden) "—" else question.answers[original],color=if(hidden) Muted else Color.White,fontSize=16.sp,lineHeight=22.sp,modifier=Modifier.weight(1f))
            }
        }
        g.votes?.let { votes ->
            Text("Помощь зала · виртуальное голосование",color=Gold,fontSize=13.sp)
            votes.forEachIndexed { i,v ->
                val fraction by animateFloatAsState(v/100f,label="vote")
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text(letters[i],color=Gold)
                    LinearProgressIndicator(progress={fraction},modifier=Modifier.weight(1f))
                    Text("$v%",color=Color.White,modifier=Modifier.width(42.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick={update(current.fifty())},enabled=ready && !g.aids[g.player].fifty,modifier=Modifier.weight(1f)){Text("50 на 50")}
            OutlinedButton(onClick={update(current.audience())},enabled=ready && !g.aids[g.player].audience,modifier=Modifier.weight(1f)){Text("Помощь зала")}
        }
        if(g.phase==Phase.FEEDBACK) {
            Text(if(g.correct) "ПРАВИЛЬНО" else "Правильный ответ: ${question.answers[question.correctOriginalIndex]}",color=if(g.correct) Color(0xFF4DDE9A) else Color(0xFFFFA3AA))
            Action(if(g.mode==GameMode.DUEL) "Передать ход" else if(!g.correct || g.round==15) "Результат" else "Следующий вопрос") { update(current.next(QuestionBank.playable)) }
        }
        if(g.mode==GameMode.MILLION) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            TextButton(onClick={ladder=true}){Text("Лестница")}
            TextButton(onClick={cashout=true},enabled=ready){Text("Забрать ${points(ShowGame.ladder.getOrElse(g.scores[0]-1){0})}")}
        }
        if(voice && speechDone && question.difficulty==0 && ready) TextButton(onClick={
            val id=context.resources.getIdentifier("l%04d_question".format(question.id),"raw",context.packageName)
            if(id!=0) StudioAudio.speak(context,listOf(id))
        }){Text("Повторить вопрос")}
    }
    if(ladder) AlertDialog(onDismissRequest={ladder=false},title={Text("Путь к миллиону")},text={Column(Modifier.verticalScroll(rememberScrollState())) {
        ShowGame.ladder.indices.reversed().forEach { i -> Text("${i+1}.  ${points(ShowGame.ladder[i])}${if(i==4 || i==9) "  ◆" else ""}",color=if(i==g.turn) Gold else Muted,modifier=Modifier.padding(3.dp)) }
    }},confirmButton={TextButton(onClick={ladder=false}){Text("Продолжить")}})
    if(cashout) AlertDialog(onDismissRequest={cashout=false},title={Text("Забрать результат?")},text={Text("Вы получите ${points(ShowGame.ladder.getOrElse(g.scores[0]-1){0})} игровых баллов. Партия завершится.")},confirmButton={TextButton(onClick={StudioAudio.stopSpeech();update(current.takePrize());cashout=false}){Text("Забрать")}},dismissButton={TextButton(onClick={cashout=false}){Text("Играть дальше")}})
}

@Composable private fun Page(content: @Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp),content=content)
}
@Composable private fun Title(text:String) { Text(text,color=Color.White,fontSize=30.sp,lineHeight=36.sp,fontWeight=FontWeight.Black) }
@Composable private fun Action(text:String,subtitle:String?=null,onClick:()->Unit) {
    Button(onClick,modifier=Modifier.fillMaxWidth().heightIn(min=58.dp),shape=RoundedCornerShape(16.dp)) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(text,fontWeight=FontWeight.Bold,fontSize=17.sp);subtitle?.let{Text(it,fontSize=12.sp)} }
    }
}
@Composable private fun Toggle(text:String,checked:Boolean,change:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Text(text,Modifier.weight(1f),color=Color.White);Switch(checked,change) }
}
@Composable private fun Reward(title:String,description:String,unlocked:Boolean) {
    Surface(shape=RoundedCornerShape(16.dp),color=Color(0xFF172741)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) { Text("${if(unlocked) "◆" else "◇"} $title",color=if(unlocked) Gold else Muted,fontWeight=FontWeight.Bold);Text(description,color=Muted,fontSize=14.sp) }
    }
}
