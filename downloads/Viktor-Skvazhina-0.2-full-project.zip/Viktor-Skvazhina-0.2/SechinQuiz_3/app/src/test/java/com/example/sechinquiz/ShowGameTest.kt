package com.example.sechinquiz

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random
import java.io.*

class ShowGameTest {
    private fun start(mode: GameMode = GameMode.MILLION, seed: Int = 7) = ShowGame.start(mode,QuestionBank.playable,random=Random(seed))
    private fun answer(g: ShowGame, right: Boolean): ShowGame {
        val q = g.copy(phase=Phase.QUESTION)
        val option = if(right) q.question.correctOriginalIndex else q.order.first{it!=q.question.correctOriginalIndex}
        return q.choose(option).reveal().next(QuestionBank.playable,Random(9))
    }
    @Test fun bankIsCompleteAndValid() {
        assertEquals(119,QuestionBank.playable.size)
        assertEquals(119,QuestionBank.playable.map{it.id}.distinct().size)
        assertFalse(QuestionBank.playable.any{it.id==20})
        QuestionBank.playable.forEach { q ->
            assertEquals("Question ${q.id}",4,q.answers.size)
            assertTrue(q.correctOriginalIndex in 0..3)
            assertTrue(q.text.isNotBlank())
            assertTrue(q.answers.all{it.isNotBlank() && '*' !in it})
        }
    }
    @Test fun millionaireHasFifteenDistinctIncreasingQuestions() {
        repeat(100) { seed ->
            val g=start(seed=seed)
            assertEquals(15,g.deck.size)
            assertEquals(15,g.deck.map{it.id}.distinct().size)
            assertEquals(listOf(5,4,3,3),(0..3).map{tier->g.deck.count{it.difficulty==tier}})
            assertEquals(g.deck.map{it.difficulty}.sorted(),g.deck.map{it.difficulty})
            assertTrue(g.callAt==-1 || g.callAt in 2..11)
        }
    }
    @Test fun winAndGuarantees() {
        var g=start()
        repeat(15) { g=answer(g,true) }
        assertEquals(Phase.RESULT,g.phase);assertTrue(g.won);assertEquals(1_000_000,g.prize)
        for((count,prize) in listOf(0 to 0,4 to 0,5 to 1_000,9 to 1_000,10 to 32_000,14 to 32_000)) {
            var failed=start();repeat(count){failed=answer(failed,true)};failed=answer(failed,false)
            assertEquals(prize,failed.prize);assertEquals(Phase.RESULT,failed.phase);assertFalse(failed.won)
        }
    }
    @Test fun cashoutAndAnswerLock() {
        var g=start();repeat(7){g=answer(g,true)}
        assertEquals(4_000,g.takePrize().prize);assertTrue(g.takePrize().walked)
        val locked=g.choose(g.question.correctOriginalIndex)
        assertEquals(locked,locked.choose(locked.order.first{it!=locked.selected}))
        assertEquals(locked,locked.takePrize())
    }
    @Test fun lifelinesAreOncePerPlayerAndCannotRemoveCorrectAnswer() {
        var g=start(GameMode.DUEL).copy(phase=Phase.QUESTION).fifty(Random(2))
        assertEquals(2,g.hidden.size);assertFalse(g.question.correctOriginalIndex in g.hidden)
        assertEquals(g,g.fifty());assertFalse(g.aids[1].fifty)
        assertEquals(g,g.choose(g.hidden.first()))
        g=g.audience(Random(4))
        assertEquals(100,g.votes!!.sum());g.order.forEachIndexed{i,a->if(a in g.hidden)assertEquals(0,g.votes!![i])}
        assertEquals(g,g.audience())
        g=answer(g,true).copy(phase=Phase.QUESTION)
        assertFalse(g.aids[g.player].fifty);assertFalse(g.aids[g.player].audience)
        assertEquals(2,g.fifty().hidden.size)
    }
    @Test fun audienceAlwaysSumsToOneHundredAndCanBeWrong() {
        var mistakes=0
        repeat(200) { seed ->
            val g=start(seed=seed).audience(Random(seed))
            assertEquals(100,g.votes!!.sum());assertTrue(g.votes!!.all{it>=0})
            if(g.order[g.votes!!.indexOf(g.votes!!.maxOrNull())]!=g.question.correctOriginalIndex) mistakes++
            val after=g.fifty(Random(seed));assertNull(after.votes);assertTrue(after.aids[0].audience)
        }
        assertTrue(mistakes>0)
    }
    @Test fun duelOnlyEndsAfterEqualTurnsAndNoRepeats() {
        var g=start(GameMode.DUEL)
        assertEquals(Phase.HANDOFF,g.phase)
        g.deck.chunked(2).forEach{assertEquals(it[0].difficulty,it[1].difficulty)}
        repeat(10) { turn ->
            g=answer(g,turn%2==0)
            if(turn<9)assertNotEquals(Phase.RESULT,g.phase)
        }
        assertEquals(Phase.RESULT,g.phase);assertEquals(listOf(5,0),g.scores)
    }
    @Test fun tiedDuelGivesBothPlayersATiebreakQuestion() {
        var g=start(GameMode.DUEL)
        repeat(10){g=answer(g,true)}
        assertEquals(Phase.HANDOFF,g.phase);assertEquals(12,g.deck.size)
        assertEquals(12,g.deck.map{it.id}.distinct().size)
        g=answer(g,true);assertNotEquals(Phase.RESULT,g.phase)
        g=answer(g,false);assertEquals(Phase.RESULT,g.phase);assertEquals(listOf(6,5),g.scores)
    }
    @Test fun exhaustedBankEndsAsAnHonestDraw() {
        var g=start(GameMode.DUEL)
        repeat(10){g=answer(g,false)}
        while(g.phase!=Phase.RESULT)g=answer(g,false)
        assertNull(g.winner);assertEquals(1,g.turn%2)
        assertEquals(g.deck.size,g.deck.map{it.id}.distinct().size)
    }
    @Test fun gameSurvivesSerializationDuringReveal() {
        val g=start().fifty().choose(start().question.correctOriginalIndex)
        val bytes=ByteArrayOutputStream().also { stream->ObjectOutputStream(stream).use{it.writeObject(g)} }.toByteArray()
        val restored=ObjectInputStream(ByteArrayInputStream(bytes)).use{it.readObject() as ShowGame}
        assertEquals(g,restored)
    }
}
