package com.example.sechinquiz

import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.test.core.app.ApplicationProvider
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class StudioUiTest {
    @get:Rule val compose = createComposeRule()
    @Before fun prepare() {
        ApplicationProvider.getApplicationContext<Context>().getSharedPreferences("studio",0).edit().clear()
            .putBoolean("music",false).putBoolean("voice",false).putBoolean("effects",false).putBoolean("animated",false).commit()
        MainActivity.foreground=true
    }
    @Test fun menuStartsFifteenQuestionGameAndRestoresState() {
        val restoration=StateRestorationTester(compose)
        restoration.setContent { StudioApp() }
        compose.onNodeWithText("Путь к миллиону").performClick()
        compose.onNodeWithText("ВОПРОС 1 / 15").assertIsDisplayed()
        compose.onNodeWithText("50 на 50").performScrollTo().performClick()
        compose.onAllNodesWithText("—").assertCountEquals(2)
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithText("ВОПРОС 1 / 15").assertExists()
        compose.onAllNodesWithText("—").assertCountEquals(2)
        compose.onNodeWithText("50 на 50").assertIsNotEnabled()
    }
    @Test fun duelHidesQuestionUntilPlayerIsReady() {
        compose.setContent { StudioApp() }
        compose.onNodeWithText("Дуэль").performClick()
        compose.onNodeWithText("Начать дуэль").performClick()
        compose.onNodeWithText("Передайте телефон").assertIsDisplayed()
        compose.onNodeWithText("50 на 50").assertDoesNotExist()
        compose.onNodeWithText("Я готов — показать вопрос").performClick()
        compose.onNodeWithText("Игрок 1 · РАУНД 1").assertIsDisplayed()
    }
    @Test fun rewardsAreLockedBeforeFirstWin() {
        compose.setContent { StudioApp() }
        compose.onNodeWithText("Награды").performScrollTo().performClick()
        compose.onNodeWithText("◇ Легенда промысла").assertExists()
        compose.onNodeWithText("Золотой костюм").assertDoesNotExist()
    }
}
